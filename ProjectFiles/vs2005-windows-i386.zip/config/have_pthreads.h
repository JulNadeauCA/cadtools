#ifndef HAVE_PTHREADS
#define HAVE_PTHREADS "yes"
#endif
