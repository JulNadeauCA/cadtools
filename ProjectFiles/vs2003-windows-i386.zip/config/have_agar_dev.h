#ifndef HAVE_AGAR_DEV
#define HAVE_AGAR_DEV "yes"
#endif
