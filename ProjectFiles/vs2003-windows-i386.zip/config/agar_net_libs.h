#ifndef AGAR_NET_LIBS
#define AGAR_NET_LIBS "ag_net"
#endif
