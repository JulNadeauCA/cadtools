#ifndef VERSION
#define VERSION "08122007"
#endif
