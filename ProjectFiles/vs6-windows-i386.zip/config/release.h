#ifndef RELEASE
#define RELEASE "Worlds of Glass"
#endif
