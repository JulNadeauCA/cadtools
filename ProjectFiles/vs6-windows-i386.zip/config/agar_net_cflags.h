#ifndef AGAR_NET_CFLAGS
#define AGAR_NET_CFLAGS ""
#endif
