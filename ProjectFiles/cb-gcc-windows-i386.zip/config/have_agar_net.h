#ifndef HAVE_AGAR_NET
#define HAVE_AGAR_NET "yes"
#endif
