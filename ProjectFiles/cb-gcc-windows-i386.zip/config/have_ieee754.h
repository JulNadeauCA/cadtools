#ifndef HAVE_IEEE754
#define HAVE_IEEE754 "yes"
#endif
